
import './List.css';


function List(props) {



    const editInput = {
        flag: true
    }



    return (


        <div>
            <input value={props.data} onChange={props.myOnChangeHandler} readOnly={editInput.flag}></input>

            <div className="myIcons">

            {/* Updating icon  */}
            <span className="material-symbols-outlined updateIcon" onClick={() => {
                props.myValue.map((element, index) => {



                    // console.log(element),
                    // console.log(props.myId),
                    // console.log("MY VALUE CURRENT : ", props.myValue[props.myId])
                    // console.log("My index: ", index)


                    if (index === props.myId) {

                        return console.log("My index: ", index);


                    }
                    else {

                        return console.log("not found");

                    }







                })
            }}>
                edit_note
            </span>

            {/* Deleting ion */}
            <span className="material-symbols-outlined deleteIcon" onClick={() => { props.onDelete(props.myId) }}>
                delete
            </span>
            </div>
        </div>






    );
}

export default List;