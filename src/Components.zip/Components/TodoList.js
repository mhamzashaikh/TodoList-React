import { useState } from "react";
import './TodoList.css';
import List from './List';
import Input from './Input';


function TodoList() {
    const [value, setValue] = useState([]);
    const [text, setText] = useState("");

    console.log("value:", value, "text: ", text);




    // For Storing input Text in setText
    const storingText = (e) => {
        setText(e.target.value)
    }


    // For Add Button
    const updateList = () => {

        setValue([...value, text]);

        setText("");
    }


    // For Delete Button
    const deleteItem = (id) => {

        console.log("Yes");


        // deleting only that value which was clicked, Condition : add only that values in setValue state whose indexNum not equal to id & those(indexNum and id) is matched will be deleted or remove from our TodoList.

        setValue((oldArrItems) => {
            return oldArrItems.filter((arrElement, indexNum) => {
                console.log("arrayElement " + arrElement + " index: " + indexNum + " id: " + id);
                return indexNum !== id;
            })


        })

    }


    const listInputHandler = (e) => {
        setText(e.target.value)

    }

    // for Update button



    return (

        <div className="container">
            <div className="subContainer">
            <div className="childContainer">
            <h1>Todo List</h1>
                {/* Input component with add button  */}
                <Input myText={text} myOnClick={updateList} mySettingText={storingText} />

                {/* List component having edit and delete button */}
                {value.map((arr, index) => {
                    return (
                        <List key={index} data={arr} onDelete={deleteItem} myId={index} myOnChangeHandler={listInputHandler} myValue={value} />
                    );
                })}
                </div>

            </div>


        </div>




    );
}

export default TodoList;