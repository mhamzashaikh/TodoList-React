import './Input.css';
function Input(props) {

    return (
        <>
            <input type="text" placeholder="Enter here....." value={props.myText} onChange={props.mySettingText} />
            <button onClick={props.myOnClick}>Add Item</button>

        </>



    );
}

export default Input;